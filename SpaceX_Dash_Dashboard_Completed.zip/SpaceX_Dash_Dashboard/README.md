# SpaceX Launch Records Dashboard — Completed Lab

This project completes the IBM hands-on lab **Build an Interactive Dashboard with Plotly Dash**.

## Included files

- `app.py` — completed Dash application with all four required tasks.
- `requirements.txt` — Python dependencies.
- `README.md` — setup and run instructions.

## Run on Windows (PowerShell)

1. Extract the ZIP file.
2. Open PowerShell in the extracted `SpaceX_Dash_Dashboard` folder.
3. (Recommended) Create and activate a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install packages:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the dashboard:

   ```powershell
   python app.py
   ```

6. Open **http://127.0.0.1:8050** in your browser.

The app automatically downloads the official IBM `spacex_launch_dash.csv` dataset on first run. If the download fails, download the CSV from the IBM lab dataset URL and put it in the same folder as `app.py`.

## Completed lab tasks

1. Launch-site dropdown (`site-dropdown`) with an **All Sites** option and searchable site names.
2. Callback for `success-pie-chart`: successful launch counts across all sites, or success/failure split for one selected site.
3. Payload range slider (`payload-slider`) from 0 to 10,000 kg in 1,000 kg steps.
4. Callback for `success-payload-scatter-chart`: payload mass vs. launch outcome, coloured by booster version category, filtered by selected site and payload range.

## Additional analysis

The dashboard also calculates tables for:
- launch counts and success rate by site,
- success rate by payload range,
- success rate by booster version category.

These are calculated from the dataset at runtime, rather than hard-coded.

## Screenshots and GitHub submission

After launching the dashboard:
- Take a screenshot of the full dashboard with **All Sites** selected.
- Take another screenshot with one launch site selected and a narrower payload range.
- Save the screenshots in a `screenshots` folder.
- To upload to GitHub, create a repository and push this project folder. Do not include `.venv` or other environment folders.

The lab asks you to include screenshots and the GitHub repository URL in your presentation. These steps require your own GitHub account and browser session.
