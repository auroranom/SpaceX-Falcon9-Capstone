"""
IBM Applied Data Science Capstone
Hands-on Lab: Build an Interactive Dashboard with Plotly Dash

Run:
    python -m pip install -r requirements.txt
    python app.py

Then open http://127.0.0.1:8050 in your browser.
"""
from pathlib import Path
import urllib.request

import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "spacex_launch_dash.csv"
DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBM-DS0321EN-SkillsNetwork/datasets/spacex_launch_dash.csv"
)

def load_data():
    """Load the lab CSV; download it automatically if it is not beside app.py."""
    if not CSV_PATH.exists():
        try:
            urllib.request.urlretrieve(DATA_URL, CSV_PATH)
        except Exception as exc:
            raise RuntimeError(
                "Could not download spacex_launch_dash.csv. "
                "Download it from the IBM lab dataset URL and place it beside app.py. "
                f"Details: {exc}"
            ) from exc

    df = pd.read_csv(CSV_PATH)
    required = {
        "Launch Site", "class", "Payload Mass (kg)", "Booster Version Category"
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            "The CSV is missing required columns: "
            + ", ".join(sorted(missing))
            + ". Please use the IBM spacex_launch_dash.csv dataset."
        )

    df = df.copy()
    df["class"] = pd.to_numeric(df["class"], errors="coerce")
    df["Payload Mass (kg)"] = pd.to_numeric(
        df["Payload Mass (kg)"], errors="coerce"
    )
    df = df.dropna(subset=["Launch Site", "class", "Payload Mass (kg)"])
    df["class"] = df["class"].astype(int)
    df = df[df["class"].isin([0, 1])]
    return df

spacex_df = load_data()
min_payload = max(0, int(spacex_df["Payload Mass (kg)"].min() // 1000 * 1000))
max_payload = min(10000, int((spacex_df["Payload Mass (kg)"].max() + 999) // 1000 * 1000))
if max_payload <= min_payload:
    min_payload, max_payload = 0, 10000

site_names = sorted(spacex_df["Launch Site"].dropna().unique())
dropdown_options = [{"label": "All Sites", "value": "ALL"}] + [
    {"label": site, "value": site} for site in site_names
]

app = Dash(__name__)
app.title = "SpaceX Launch Records Dashboard"

app.layout = html.Div(
    style={
        "maxWidth": "1200px", "margin": "0 auto", "padding": "24px",
        "fontFamily": "Arial, sans-serif", "backgroundColor": "#f7f9fc"
    },
    children=[
        html.H1(
            "SpaceX Launch Records Dashboard",
            style={"textAlign": "center", "color": "#172554"}
        ),
        html.P(
            "Explore Falcon 9 launch outcomes by launch site, payload mass and booster version.",
            style={"textAlign": "center", "color": "#475569"}
        ),
        html.Div([
            html.Label("Select Launch Site:", style={"fontWeight": "bold"}),
            dcc.Dropdown(
                id="site-dropdown",
                options=dropdown_options,
                value="ALL",
                placeholder="Select a Launch Site here",
                searchable=True,
                clearable=False
            )
        ], style={"margin": "20px 0"}),
        html.Div([
            dcc.Graph(id="success-pie-chart")
        ], style={"backgroundColor": "white", "padding": "12px", "borderRadius": "8px"}),
        html.Div([
            html.Label("Select Payload Mass Range (Kg):", style={"fontWeight": "bold"}),
            dcc.RangeSlider(
                id="payload-slider",
                min=0,
                max=10000,
                step=1000,
                marks={i: f"{i:,}" for i in range(0, 10001, 1000)},
                value=[min_payload, max_payload],
                tooltip={"placement": "bottom", "always_visible": True}
            )
        ], style={"margin": "32px 12px"}),
        html.Div([
            dcc.Graph(id="success-payload-scatter-chart")
        ], style={"backgroundColor": "white", "padding": "12px", "borderRadius": "8px"}),
        html.H2("Quick data insights", style={"color": "#172554"}),
        html.Div(id="insights-table"),
        html.P(
            "Success means class = 1; failure means class = 0. "
            "Success rates are calculated from the records in the supplied lab dataset.",
            style={"fontSize": "12px", "color": "#64748b", "marginTop": "18px"}
        )
    ]
)

@app.callback(
    Output(component_id="success-pie-chart", component_property="figure"),
    Input(component_id="site-dropdown", component_property="value")
)
def get_pie_chart(entered_site):
    if entered_site == "ALL":
        counts = (
            spacex_df[spacex_df["class"] == 1]
            .groupby("Launch Site").size()
            .reset_index(name="Successful Launches")
        )
        fig = px.pie(
            counts,
            values="Successful Launches",
            names="Launch Site",
            title="Successful Launch Counts by Site (All Sites)"
        )
    else:
        filtered_df = spacex_df[spacex_df["Launch Site"] == entered_site]
        counts = (
            filtered_df["class"].value_counts()
            .reindex([1, 0], fill_value=0)
            .rename_axis("Launch Outcome")
            .reset_index(name="Count")
        )
        counts["Launch Outcome"] = counts["Launch Outcome"].map(
            {1: "Success", 0: "Failure"}
        )
        fig = px.pie(
            counts,
            values="Count",
            names="Launch Outcome",
            title=f"Launch Outcomes for {entered_site}"
        )
    fig.update_traces(textposition="inside", textinfo="label+percent+value")
    fig.update_layout(legend_title_text="Launch Site / Outcome")
    return fig

@app.callback(
    Output(component_id="success-payload-scatter-chart", component_property="figure"),
    [
        Input(component_id="site-dropdown", component_property="value"),
        Input(component_id="payload-slider", component_property="value")
    ]
)
def get_scatter_plot(entered_site, payload_range):
    low, high = payload_range
    filtered_df = spacex_df[
        spacex_df["Payload Mass (kg)"].between(low, high, inclusive="both")
    ]
    if entered_site != "ALL":
        filtered_df = filtered_df[filtered_df["Launch Site"] == entered_site]

    title_site = "All Launch Sites" if entered_site == "ALL" else entered_site
    fig = px.scatter(
        filtered_df,
        x="Payload Mass (kg)",
        y="class",
        color="Booster Version Category",
        hover_data=[
            c for c in ["Flight Number", "Launch Site", "Booster Version"]
            if c in filtered_df.columns
        ],
        title=f"Payload vs. Launch Outcome — {title_site}",
        labels={"class": "Launch Outcome (0 = Failure, 1 = Success)"}
    )
    fig.update_yaxes(tickmode="array", tickvals=[0, 1], ticktext=["Failure", "Success"])
    fig.update_layout(legend_title_text="Booster Version")
    return fig

@app.callback(
    Output("insights-table", "children"),
    Input("site-dropdown", "value")
)
def render_insights(_selected_site):
    # Insights are calculated across the full dataset, regardless of dropdown selection.
    site_stats = spacex_df.groupby("Launch Site").agg(
        launches=("class", "size"),
        successful=("class", "sum"),
        success_rate=("class", "mean")
    ).reset_index()
    site_stats["Success Rate"] = (site_stats["success_rate"] * 100).round(1).astype(str) + "%"
    site_stats = site_stats.sort_values(["successful", "success_rate"], ascending=False)

    payload_bins = [0, 2000, 4000, 6000, 8000, 10000, float("inf")]
    payload_labels = ["0–2,000", "2,001–4,000", "4,001–6,000", "6,001–8,000", "8,001–10,000", ">10,000"]
    temp = spacex_df.copy()
    temp["Payload Range (kg)"] = pd.cut(
        temp["Payload Mass (kg)"], bins=payload_bins, labels=payload_labels,
        include_lowest=True
    )
    payload_stats = temp.groupby("Payload Range (kg)", observed=False)["class"].agg(
        launches="size", success_rate="mean"
    ).reset_index()
    payload_stats = payload_stats.dropna(subset=["success_rate"])
    payload_stats["Success Rate"] = (payload_stats["success_rate"] * 100).round(1).astype(str) + "%"

    booster_stats = spacex_df.groupby("Booster Version Category")["class"].agg(
        launches="size", success_rate="mean"
    ).reset_index()
    booster_stats["Success Rate"] = (booster_stats["success_rate"] * 100).round(1).astype(str) + "%"
    booster_stats = booster_stats.sort_values(["success_rate", "launches"], ascending=False)

    def make_table(df, columns, heading):
        return html.Div([
            html.H4(heading, style={"color": "#334155"}),
            html.Table([
                html.Thead(html.Tr([html.Th(c, style=TH_STYLE) for c in columns])),
                html.Tbody([
                    html.Tr([
                        html.Td(str(row[c]), style=TD_STYLE) for c in columns
                    ]) for _, row in df[columns].iterrows()
                ])
            ], style={"width": "100%", "borderCollapse": "collapse", "backgroundColor": "white"})
        ], style={"marginBottom": "22px", "overflowX": "auto"})

    return html.Div([
        make_table(site_stats.rename(columns={
            "Launch Site": "Launch Site", "launches": "Launches", "successful": "Successful Launches"
        }), ["Launch Site", "Launches", "Successful Launches", "Success Rate"], "Launch site performance"),
        make_table(payload_stats.rename(columns={
            "Payload Range (kg)": "Payload Range (kg)", "launches": "Launches"
        }), ["Payload Range (kg)", "Launches", "Success Rate"], "Success rate by payload range"),
        make_table(booster_stats.rename(columns={
            "Booster Version Category": "Booster Version", "launches": "Launches"
        }), ["Booster Version", "Launches", "Success Rate"], "Success rate by booster version")
    ])

TH_STYLE = {
    "textAlign": "left", "padding": "10px", "backgroundColor": "#e2e8f0",
    "border": "1px solid #cbd5e1"
}
TD_STYLE = {"padding": "9px", "border": "1px solid #e2e8f0"}

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=8050)
